<?php

echo "index2.php, index3.php, index4.php";

?>
