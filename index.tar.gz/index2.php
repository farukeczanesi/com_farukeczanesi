<?php

echo "ip adresiniz yasaklandi :)";

?>
